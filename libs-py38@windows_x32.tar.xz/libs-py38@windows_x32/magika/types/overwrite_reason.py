# Copyright 2024 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# ruff: noqa: D100


import enum

from magika.types.strenum import LowerCaseStrEnum


class OverwriteReason(LowerCaseStrEnum):
    """Enum to represent possible reasons for overriding the model's prediction.

    Consult the documentation for additional context.
    """

    NONE = enum.auto()
    LOW_CONFIDENCE = enum.auto()
    OVERWRITE_MAP = enum.auto()
